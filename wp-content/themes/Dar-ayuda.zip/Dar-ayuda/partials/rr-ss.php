<?php
    $facebook = get_theme_mod('Redes_sociales_FB');
    $instagram = get_theme_mod('Redes_sociales_IG');
  ?>
<div class="main-banner__rrss">
    <a href="<?php echo $facebook; ?>" target="_blank">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/fb_2.png">
    </a>
    <a href="<?php echo $instagram; ?>" target="_blank">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/ig_2.png">
    </a>
  </div>